package student.fee.module.springboot.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "student")
public class Student {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "first_name")
	private String firstName;

	@Column(name = "last_name")
	private String lastName;
	
	@Column(name = "email_id")
	private String emailId;
	
	@Column(name = "reg_no")
	private String regNo;
	
	@Column(name = "stud_dob")
	private Date studDob;
	
	
	@Column(name = "stud_addr")
	private String studAddr;
	
	@Column(name = "stud_cont")
	private long studCont;
	
	@Column(name = "stud_branch")
	private String studBranch;
	
	@Column(name = "stud_schl")
	private String studSchl;
	
	@Column(name = "stud_Sem")
	private String studSem;

	public Student () {
	}
	
	

	
	@Override
	public String toString() {
		return "Student [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", emailId=" + emailId
				+ ", regNo=" + regNo + ", studDob=" + studDob + ", studAddr=" + studAddr + ", studCont=" + studCont
				+ ", studBranch=" + studBranch + ", studSchl=" + studSchl + ", studsem=" + studSem + "]";
	}

	public Student(long id, String firstName, String lastName, String emailId, String regNo, Date studDob,
			String studAddr, long studCont, String studBranch, String studSchl, String studSem) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.regNo = regNo;
		this.studDob = studDob;
		this.studAddr = studAddr;
		this.studCont = studCont;
		this.studBranch = studBranch;
		this.studSchl = studSchl;
		this.studSem = studSem;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getRegNo() {
		return regNo;
	}

	public void setRegNo(String regNo) {
		this.regNo = regNo;
	}

	public Date getStudDob() {
		return studDob;
	}

	public void setStudDob(Date studDob) {
		this.studDob = studDob;
	}

	public String getStudAddr() {
		return studAddr;
	}

	public void setStudAddr(String studAddr) {
		this.studAddr = studAddr;
	}

	public long getStudCont() {
		return studCont;
	}

	public void setStudCont(long studCont) {
		this.studCont = studCont;
	}

	public String getStudBranch() {
		return studBranch;
	}

	public void setStudBranch(String studBranch) {
		this.studBranch = studBranch;
	}

	public String getStudSchl() {
		return studSchl;
	}

	public void setStudSchl(String studSchl) {
		this.studSchl = studSchl;
	}

	public String getStudSem() {
		return studSem;
	}

	public void setStudSem(String studSem) {
		this.studSem = studSem;
	}
	
	

}

















